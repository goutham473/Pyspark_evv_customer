class AppConf(object):
    def __init__(self,inputpath, inputfilename, outputpath, outputfilename):
        self.inputpath = inputpath
        self.inputfilename = inputfilename
        self.outputpath = outputpath
        self.outputfilename = outputfilename
