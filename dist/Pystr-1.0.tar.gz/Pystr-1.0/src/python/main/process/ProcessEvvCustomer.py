#from src.python.main.conf.appConf import AppConf
from read.read_tables_file import *
from pyspark.sql.functions import *
from write.write_tgt_file import *


class ProcessEvvCustomer(object):

    def process_evv_cust_exec(self, spark, app_conf):
        readSrcTablefile = textRead(spark, app_conf.inputpath + "/" + app_conf.inputfilename).collect()
        readonebyone = [str(row['value']) for row in readSrcTablefile]
        readdata = [csvRead(spark, app_conf.inputpath + "/" + row) for row in readonebyone]
        readtoccabc = readdata[0].withColumn("CCABC", expr("CABC")).withColumn('ICABC', expr("IABC")).cache()
        readtoccasetyperabc = readdata[1].withColumn('CTRCABC', expr("CABC")).withColumn('CTRIABC', expr('IABC'))
        readtocearningsrecabc = readdata[2].withColumn('ERCABC', expr("CABC")).withColumn('ERIABC', expr('IABC'))
        readtococcupatabc = readdata[3].withColumn('OCABC', expr('CABC')).withColumn('OIABC', expr('IABC'))
        readtococcupationcabc = readdata[4].withColumn('OCCABC', expr('CABC')).withColumn('OCIABC', expr('IABC'))
        readtocpartycaserabc = readdata[5].withColumn('PCRCABC', expr('CABC')).withColumn('PCRIABC', expr('IABC'))
        readtocperabc = readdata[6].withColumn('PCABC', expr('CABC')).withColumn('PIABC', expr('IABC'))
        readtolcclaimoccupatabc = readdata[7].withColumn('COCABC', expr('CABC')).withColumn('COIABC', expr('IABC'))
        readtolcontrabc = readdata[8].withColumn('CONCABC', expr('CABC')).withColumn('CONIABC', expr('IABC'))
        readtolincomesouabc = readdata[9].withColumn('IOCABC', expr('CABC')).withColumn('IOCIABC', expr('IABC'))
        readtolpartydetaabc = readdata[10].withColumn('PDCABC', expr('CABC')).withColumn('PDIABC', expr('IABC'))
        readtolpaymentprefereabc = readdata[11].withColumn('PPCABC', expr('CABC')).withColumn('PPIABC', expr('IABC'))
        readtocorganizatabc = readdata[12].withColumn('ORGCABC', expr('CABC')).withColumn('ORGIABC', expr('IABC'))
        readtocpartycontractrabc = readdata[13].withColumn('PCCABC', expr('CABC')).withColumn('PCIABC', expr('IABC'))
        readtoccontractsabc = readdata[14].withColumn('CSCABC', expr('CABC')).withColumn('CSIABC', expr('IABC'))
        readtodomaininstaabc = readdata[15].withColumn('DOMICABC', expr('CABC')).withColumn('DOMIIABC', expr('IABC'))
        readtocpointofcontabc = readdata[16].withColumn('POCCABC', expr('CABC')).withColumn('POCIABC', expr('IABC'))
        readlkpgroupindicatabc = readdata[17]
        readmtrorabc = readdata[18]
        joinPersonInfo = personSelectCol(
            #personInfo(readtocperabc, readtococcupatabc, readtocearningsrecabc, readtocorganizatabc, readtolpartydetaabc, readtolpaymentprefereabc, readtodomaininstaabc, readtococcupationcabc))
             personInfo(readtocperabc, readtococcupatabc, readtocearningsrecabc, readtocorganizatabc, readtolpartydetaabc, readtolpaymentprefereabc))
                        #, readtolpartydetaabc))
        #joinPersonInfo.show()
        filewrite = filewritecsv(joinPersonInfo)
        showdf = filewrite.show()
        csvWrite(filewrite, app_conf.outputpath + "/" + app_conf.outputfilename)


def personInfo(readtocperabc, readtococcupatabc, readtocearningsrecabc, readtocorganizatabc, readtolpartydetaabc,readtolpaymentprefereabc):
               #, readtocearningsrecabc, readtocorganizatabc, readtolpartydetaabc):
        return readtocperabc.join(readtococcupatabc, (readtocperabc['PCABC'] == readtococcupatabc['OCABC']) & (readtocperabc['PIABC'] == readtococcupatabc['OIABC']), "left")\
            .join(readtocearningsrecabc, (readtococcupatabc['OCABC'] == readtocearningsrecabc['C_OCOCCPTN_EARNINGSRECORABC']) & (readtococcupatabc['OIABC'] == readtocearningsrecabc['I_OCOCCPTN_EARNINGSRECORABC']), "left")\
            .join(readtocorganizatabc, (readtococcupatabc['C_OCPRTY_EMPLOYEEOCCUPABC'] == readtocorganizatabc['CABC']) & (readtococcupatabc['I_OCPRTY_EMPLOYEEOCCUPABC'] == readtocorganizatabc['IABC']), "left")\
            .join(readtolpartydetaabc, (readtocperabc['PCABC'] == readtolpartydetaabc['C_OCPRTY_PARTYABC']) & (readtocperabc['PIABC'] == readtolpartydetaabc['I_OCPRTY_PARTYABC']))\
            .join(readtolpaymentprefereabc, (readtolpartydetaabc['PDCABC'] == readtolpaymentprefereabc['C_PRTDTLS_PAYMENTPREFERABC']) & (readtolpartydetaabc['PDIABC'] == readtolpaymentprefereabc['I_PRTDTLS_PAYMENTPREFERABC']), "left")
#            .join(readtodomaininstaabc, ['EXTPAYMENTROUTINGABC'] == readtodomaininstaabc['DOMIIABC'], "left")\
#            .join(readtococcupationcabc, readtococcupatabc['I_OCCUPCDE_OCCUPATIONSABC'] == readtococcupationcabc['OCIABC'],"left")

def personSelectCol(personInf):
        return personInf.select(personInf['PCABC'], personInf['PIABC'], personInf['NatlnsNoABC'].alias('CSTMR_SN')
                                ,personInf['FIRSTNAMESABC'].alias('CSTMR_FST_NAM'), personInf['INITIALSABC'].alias('CSTMR_MI_NAM')
                                ,datediff(personInf['DateOfBirthABC'], current_date()).alias('cstmr_age'))


def filewritecsv(personSelectCol):
        return personSelectCol.select(personSelectCol.PCABC, personSelectCol.PIABC, personSelectCol.CSTMR_SN, personSelectCol.CSTMR_FST_NAM
                                      )





